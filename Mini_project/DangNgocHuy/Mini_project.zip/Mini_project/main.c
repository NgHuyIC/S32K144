/*
 * @file    main.c
 * @brief   Demo for GPIO Initialization and Control_Mini Project
 * @details This file demonstrates the usage of GPIO functions to control LEDs and handle button interrupts.
 *          PTC12  ~ Button - SW2
 *          PTC13  ~ Button - SW3
 *          Pull down --> Press is High logic
 *                     --> Release is Low logic
 *          Green Led : Port D-pin 16
 *          Red Led: Port D-pin 15
 *          Blue Led: Port D-pin 0
 */
/*==================================================================================================
 *                                        INCLUDE FILES
==================================================================================================*/

/*==================================================================================================
 *                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/

/*==================================================================================================
 *                                       LOCAL MACROS
==================================================================================================*/
#define PCC_PORTC            (*(volatile unsigned int*)(0x40065000u + 0x12C))
#define PORTC_PCR_PIN12      (*(volatile unsigned int*)(0x4004B000u + 0x30))
#define GPIOC_PDDR           (*(volatile unsigned int*)(0x400FF080u + 0x12))
#define GPIOC_PDIR           (*(volatile const unsigned int*)(0x400FF080u + 0x10))
#define PORTC_PCR_PIN13      (*(volatile unsigned int*)(0x4004B000u + 0x34))

#define PCC_PORTD            (*(volatile unsigned int*)(0x40065000u + 0x130))
#define PORTD_PCR_PIN16      (*(volatile unsigned int*)(0x4004C000 + 16 * 4)) // green led
#define PORTD_PCR_PIN15      (*(volatile unsigned int*)(0x4004C000 + 15 * 4)) // red led
#define PORTD_PCR_PIN0       (*(volatile unsigned int*)(0x4004C000 + 0 * 4))  // blue led
#define GPIOD_PDDR           (*(volatile unsigned int*)(0x400FF0C0 + 0x14))
#define GPIOD_PDOR           (*(volatile unsigned int*)(0x400FF0C0 + 0))

#define NVIC_ISER_1          (*(volatile unsigned int*)(0xE000E100u + 4 * 1))

/*==================================================================================================
 *                                      LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
 *                                      LOCAL VARIABLES
==================================================================================================*/

/*==================================================================================================
 *                                      GLOBAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
 *                                      GLOBAL VARIABLES
==================================================================================================*/
unsigned char state = 0;
unsigned char running = 0;
unsigned char inverse_running = 0;
unsigned char last_state = 0;

/*==================================================================================================
 *                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void delay(void);
void Blink_green(void);
void Blink_red(void);
void Blink_blue(void);
void next_state(void);
void Inverse_blink(void);

/*==================================================================================================
 *                                       LOCAL FUNCTIONS
==================================================================================================*/
/*!
 * @brief Delay function.
 *
 * This function introduces a delay by looping a large number of times.
 *
 * @return None
 */
void delay(void) {
    int i;
    for (i = 0; i < 1000000; i++);
}

/*!
 * @brief Sets the LEDs to display green.
 *
 * This function turns on the green LED and turns off the red and blue LEDs.
 *
 * @return None
 */
void Blink_green(void) {
    GPIOD_PDOR |= ((1 << 0) | (1 << 15)); // Turn on green LED, turn off red and blue LEDs
    GPIOD_PDOR &= ~(1 << 16);
}

/*!
 * @brief Sets the LEDs to display red.
 *
 * This function turns on the red LED and turns off the green and blue LEDs.
 *
 * @return None
 */
void Blink_red(void) {
    GPIOD_PDOR |= ((1 << 0) | (1 << 16)); // Turn on red LED, turn off green and blue LEDs
    GPIOD_PDOR &= ~(1 << 15);
}

/*!
 * @brief Sets the LEDs to display blue.
 *
 * This function turns on the blue LED and turns off the green and red LEDs.
 *
 * @return None
 */
void Blink_blue(void) {
    GPIOD_PDOR |= ((1 << 16) | (1 << 15)); // Turn on blue LED, turn off green and red LEDs
    GPIOD_PDOR &= ~(1 << 0);
}

/*!
 * @brief Changes the state of LEDs to the next pattern.
 *
 * This function cycles through different LED patterns: green, red, and blue.
 *
 * @return None
 */
void next_state(void) {
    if (state % 3 == 0) {
        Blink_green();
        last_state = 0;
    } else if (state % 3 == 1) {
        Blink_red();
        last_state = 1;
    } else if (state % 3 == 2) {
        Blink_blue();
        last_state = 2;
    }
    state++;
}

/*!
 * @brief Reverses the blinking pattern of LEDs.
 *
 * This function reverses the order of blinking LEDs based on the last state.
 *
 * @return None
 */
void Inverse_blink(void) {
    if (last_state == 0) {
        Blink_green();
        delay();
        Blink_blue();
        delay();
        Blink_red();
        delay();
    } else if (last_state == 1) {
        Blink_red();
        delay();
        Blink_green();
        delay();
        Blink_blue();
        delay();
    } else if (last_state == 2) {
        Blink_blue();
        delay();
        Blink_red();
        delay();
        Blink_green();
        delay();
    }
}

/*==================================================================================================
 *                                       GLOBAL FUNCTIONS
==================================================================================================*/

/*!
 * @brief Main function.
 *
 * Initializes GPIO, handles interrupts, and controls LED states.
 *
 * @return Always returns 0.
 */
int main() {
    /* Step 1: Interrupt Set Enable Register */
    NVIC_ISER_1 |= (1 << 29);
    
    /*------------------------*/
    /*    Config buttons      */
    /*------------------------*/
    /* Step 1: Enable clock for Port C */
    PCC_PORTC |= (1 << 30);
    
    /* Step 2: Configure Pin 12 and Pin 13 of Port C as GPIO */
    PORTC_PCR_PIN12 |= (1 << 8);
    PORTC_PCR_PIN13 |= (1 << 8);
    
    /* Step 3: Set falling-edge interrupt */
    PORTC_PCR_PIN12 |= (10 << 16);
    PORTC_PCR_PIN13 |= (10 << 16);
    
    /* Step 4: Configure Pin 12 and Pin 13 of Port C as input */
    GPIOC_PDDR &= ~(1 << 12);
    GPIOC_PDDR &= ~(1 << 13); // Configure Pin 13 as input
    
    /*------------------------*/
    /*    Config LED green    */
    /*------------------------*/
    /* Step 1: Enable clock for Port D */
    PCC_PORTD |= (1 << 30);
    
    /* Step 2: Configure Pin 16 of Port D as GPIO */
    PORTD_PCR_PIN16 |= (1 << 8);
    
    /*------------------------*/
    /*    Config red LED      */
    /* Step 1: Configure Pin 15 of Port D as GPIO */
    PORTD_PCR_PIN15 |= (1 << 8);
    
    /*------------------------*/
    /*    Config blue LED     */
    /* Step 1: Configure Pin 0 of Port D as GPIO */
    PORTD_PCR_PIN0 |= (1 << 8);
    
    /* Step 2: Configure Pin 0, 15, 16 of Port D as output */
    GPIOD_PDDR |= ((1 << 0) | (1 << 15) | (1 << 16));
    
    // Initial value of green LED
    Blink_green();
    delay();
    
    while (1) {
        if (running) {
            next_state();
            delay();
        }
        if (inverse_running) {
            Inverse_blink();
        }
    }
}

/*!
 * @brief Interrupt handler for Port C.
 *
 * Handles interrupts from Pin 12 and Pin 13 of Port C to control LED blinking modes.
 *
 * @return None
 */
void PORTC_IRQHandler(void) {
    if (PORTC_PCR_PIN12 & (1 << 24)) {
        PORTC_PCR_PIN12 |= (1 << 24);
        running = !running;
        inverse_running = 0;
    }
    if (PORTC_PCR_PIN13 & (1 << 24)) {
        PORTC_PCR_PIN13 |= (1 << 24);
        inverse_running = !inverse_running;
        running = 0;
    }
}
